from itertools import *
from Crypto.Util.strxor import strxor
import os

from Crypto.Util.number import getPrime, long_to_bytes, bytes_to_long
import gmpy2


p=getPrime(1024)
q=getPrime(1024)
n=p*q
e=getPrime(256)
phi=(p-1)*(q-1)
assert(gmpy2.gcd(e, phi)==1)
d=gmpy2.invert(e, phi)

flag=b"*********************"
m=bytes_to_long(flag)
c=gmpy2.powmod(m, e, n)

toxor=("cipher"+str(c))


secret = cycle("aurora")
ran=os.urandom(6)
key = cycle(ran)
cipher = ''.join(strxor(strxor(mm, next(secret)), next(key)) for mm in toxor)

open("output", "w").write(cipher.encode("hex"))

print(e*phi+2*d+2000)
print(n)